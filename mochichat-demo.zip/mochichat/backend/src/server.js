require("dotenv").config();
const path = require("path");
const express = require("express");
const cors = require("cors");

const charactersRouter = require("./routes/characters");
const messagesRouter = require("./routes/messages");
const walletRouter = require("./routes/wallet");
const { startScheduler } = require("./services/scheduler");
const { STICKER_SET } = require("./services/claude");

const app = express();
app.use(cors());
app.use(express.json());
app.use("/uploads", express.static(path.join(__dirname, "..", "uploads")));

app.get("/api/stickers", (req, res) => res.json(STICKER_SET));
app.use("/api/characters/:id/messages", messagesRouter);
app.use("/api/characters", charactersRouter);
app.use("/api/wallet", walletRouter);

app.get("/api/health", (req, res) => res.json({ ok: true }));

const PORT = process.env.PORT || 4000;
app.listen(PORT, () => {
  console.log(`✅ Mochichat demo backend chạy tại http://localhost:${PORT}`);
  if (!process.env.ANTHROPIC_API_KEY) {
    console.warn("⚠️  Chưa có ANTHROPIC_API_KEY trong .env — AI sẽ không trả lời được.");
  }
  startScheduler();
});
