const path = require("path");
const Database = require("better-sqlite3");

const db = new Database(path.join(__dirname, "..", "mochichat.db"));
db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS characters (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  name TEXT NOT NULL,
  avatar TEXT DEFAULT '🙂',
  system_prompt TEXT DEFAULT '',
  wealth_context TEXT DEFAULT 'bình thường, đủ sống',
  messaging_style TEXT DEFAULT 'nói_nhiều', -- 'nói_ít' | 'nói_nhiều'
  proactive_enabled INTEGER DEFAULT 0,
  proactive_interval_hours REAL DEFAULT 4,
  last_message_at TEXT,
  created_at TEXT DEFAULT (datetime('now'))
);

CREATE TABLE IF NOT EXISTS messages (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  character_id INTEGER NOT NULL,
  role TEXT NOT NULL, -- 'user' | 'ai'
  type TEXT DEFAULT 'text', -- 'text' | 'sticker' | 'image'
  content TEXT NOT NULL,
  reaction TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS memories (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  character_id INTEGER NOT NULL,
  content TEXT NOT NULL,
  created_at TEXT DEFAULT (datetime('now')),
  FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS transactions (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  character_id INTEGER NOT NULL,
  amount INTEGER NOT NULL,
  note TEXT,
  status TEXT DEFAULT 'pending', -- 'pending' | 'received' | 'refunded'
  ai_reply TEXT,
  created_at TEXT DEFAULT (datetime('now')),
  resolved_at TEXT,
  FOREIGN KEY (character_id) REFERENCES characters(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS wallet (
  id INTEGER PRIMARY KEY CHECK (id = 1),
  balance INTEGER NOT NULL DEFAULT 5000000,
  spending_limit INTEGER NOT NULL DEFAULT 5000000
);
INSERT OR IGNORE INTO wallet (id, balance, spending_limit) VALUES (1, 5000000, 5000000);
`);

module.exports = db;
