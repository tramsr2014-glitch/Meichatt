const express = require("express");
const db = require("../db");
const { decideTransaction } = require("../services/claude");

const router = express.Router();

router.get("/", (req, res) => {
  const wallet = db.prepare("SELECT * FROM wallet WHERE id = 1").get();
  res.json(wallet);
});

router.get("/transactions", (req, res) => {
  const rows = db
    .prepare(
      `SELECT t.*, c.name as character_name, c.avatar as character_avatar
       FROM transactions t JOIN characters c ON c.id = t.character_id
       ORDER BY t.created_at DESC`
    )
    .all();
  res.json(rows);
});

// Chuyển tiền cho 1 nhân vật
router.post("/characters/:id/transfer", async (req, res) => {
  const character = db.prepare("SELECT * FROM characters WHERE id = ?").get(req.params.id);
  if (!character) return res.status(404).json({ error: "Không tìm thấy nhân vật" });

  const amount = Number(req.body.amount);
  const note = req.body.note || "";
  if (!amount || amount <= 0) return res.status(400).json({ error: "Số tiền không hợp lệ" });

  const wallet = db.prepare("SELECT * FROM wallet WHERE id = 1").get();
  if (amount > wallet.balance) {
    return res.status(400).json({ error: "Số dư trong ví không đủ" });
  }

  // Trừ tiền ngay, tạo giao dịch pending
  db.prepare("UPDATE wallet SET balance = balance - ? WHERE id = 1").run(amount);
  const info = db
    .prepare(
      "INSERT INTO transactions (character_id, amount, note, status) VALUES (?, ?, ?, 'pending')"
    )
    .run(character.id, amount, note);
  const transactionId = info.lastInsertRowid;

  // Ghi 1 tin nhắn dạng "giao dịch" vào khung chat
  db.prepare(
    "INSERT INTO messages (character_id, role, type, content) VALUES (?, 'user', 'transfer', ?)"
  ).run(character.id, JSON.stringify({ transactionId, amount, note }));

  try {
    const decision = await decideTransaction({ character, amount, note });
    const status = decision.decision === "received" ? "received" : "refunded";

    db.prepare(
      "UPDATE transactions SET status = ?, ai_reply = ?, resolved_at = datetime('now') WHERE id = ?"
    ).run(status, decision.reply, transactionId);

    if (status === "refunded") {
      db.prepare("UPDATE wallet SET balance = balance + ? WHERE id = 1").run(amount);
    }

    db.prepare(
      "INSERT INTO messages (character_id, role, type, content) VALUES (?, 'ai', 'text', ?)"
    ).run(character.id, decision.reply);

    const wallet = db.prepare("SELECT * FROM wallet WHERE id = 1").get();
    const transaction = db.prepare("SELECT * FROM transactions WHERE id = ?").get(transactionId);
    res.status(201).json({ transaction, wallet });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi khi xử lý giao dịch: " + err.message });
  }
});

module.exports = router;
