const express = require("express");
const db = require("../db");

const router = express.Router();

router.get("/", (req, res) => {
  const characters = db.prepare("SELECT * FROM characters ORDER BY created_at DESC").all();
  res.json(characters);
});

router.get("/:id", (req, res) => {
  const character = db.prepare("SELECT * FROM characters WHERE id = ?").get(req.params.id);
  if (!character) return res.status(404).json({ error: "Không tìm thấy nhân vật" });
  res.json(character);
});

router.post("/", (req, res) => {
  const {
    name,
    avatar = "🙂",
    system_prompt = "",
    wealth_context = "bình thường, đủ sống",
    messaging_style = "nói_nhiều",
    proactive_enabled = false,
    proactive_interval_hours = 4,
  } = req.body;

  if (!name || !name.trim()) return res.status(400).json({ error: "Thiếu tên nhân vật" });

  const info = db
    .prepare(
      `INSERT INTO characters (name, avatar, system_prompt, wealth_context, messaging_style, proactive_enabled, proactive_interval_hours)
       VALUES (?, ?, ?, ?, ?, ?, ?)`
    )
    .run(
      name.trim(),
      avatar,
      system_prompt,
      wealth_context,
      messaging_style,
      proactive_enabled ? 1 : 0,
      proactive_interval_hours
    );

  const character = db.prepare("SELECT * FROM characters WHERE id = ?").get(info.lastInsertRowid);
  res.status(201).json(character);
});

router.put("/:id", (req, res) => {
  const existing = db.prepare("SELECT * FROM characters WHERE id = ?").get(req.params.id);
  if (!existing) return res.status(404).json({ error: "Không tìm thấy nhân vật" });

  const merged = { ...existing, ...req.body };
  db.prepare(
    `UPDATE characters SET name=?, avatar=?, system_prompt=?, wealth_context=?, messaging_style=?,
     proactive_enabled=?, proactive_interval_hours=? WHERE id=?`
  ).run(
    merged.name,
    merged.avatar,
    merged.system_prompt,
    merged.wealth_context,
    merged.messaging_style,
    merged.proactive_enabled ? 1 : 0,
    merged.proactive_interval_hours,
    req.params.id
  );

  const character = db.prepare("SELECT * FROM characters WHERE id = ?").get(req.params.id);
  res.json(character);
});

router.delete("/:id", (req, res) => {
  db.prepare("DELETE FROM characters WHERE id = ?").run(req.params.id);
  res.status(204).end();
});

module.exports = router;
