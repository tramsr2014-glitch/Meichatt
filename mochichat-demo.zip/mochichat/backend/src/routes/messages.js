const express = require("express");
const path = require("path");
const multer = require("multer");
const db = require("../db");
const { getChatReply } = require("../services/claude");

const router = express.Router({ mergeParams: true });

const upload = multer({
  storage: multer.diskStorage({
    destination: path.join(__dirname, "..", "..", "uploads"),
    filename: (req, file, cb) => {
      cb(null, `${Date.now()}-${file.originalname.replace(/\s+/g, "_")}`);
    },
  }),
  limits: { fileSize: 10 * 1024 * 1024 },
});

function getCharacter(id) {
  return db.prepare("SELECT * FROM characters WHERE id = ?").get(id);
}

function getMemories(characterId) {
  return db
    .prepare("SELECT * FROM memories WHERE character_id = ? ORDER BY created_at DESC LIMIT 15")
    .all(characterId);
}

function getHistory(characterId) {
  return db
    .prepare("SELECT * FROM messages WHERE character_id = ? ORDER BY created_at ASC LIMIT 40")
    .all(characterId);
}

function saveMessage(characterId, role, type, content, reaction = null) {
  const info = db
    .prepare(
      "INSERT INTO messages (character_id, role, type, content, reaction) VALUES (?, ?, ?, ?, ?)"
    )
    .run(characterId, role, type, content, reaction);
  return db.prepare("SELECT * FROM messages WHERE id = ?").get(info.lastInsertRowid);
}

function touchCharacter(characterId) {
  db.prepare("UPDATE characters SET last_message_at = datetime('now') WHERE id = ?").run(
    characterId
  );
}

async function respondAndSave(character, imagePath, userText) {
  const memories = getMemories(character.id);
  const history = getHistory(character.id);

  const reply = await getChatReply({
    character,
    memories,
    history: history.slice(0, -1), // không tính tin nhắn user vừa lưu (đã có trong content riêng)
    userText,
    imagePath,
  });

  const createdMessages = [];

  for (const text of reply.messages) {
    createdMessages.push(saveMessage(character.id, "ai", "text", text));
  }
  if (reply.sticker) {
    createdMessages.push(saveMessage(character.id, "ai", "sticker", reply.sticker));
  }
  if (reply.memoryNote) {
    db.prepare("INSERT INTO memories (character_id, content) VALUES (?, ?)").run(
      character.id,
      reply.memoryNote
    );
  }
  return { createdMessages, reaction: reply.reaction };
}

// Lấy lịch sử chat
router.get("/", (req, res) => {
  const messages = db
    .prepare("SELECT * FROM messages WHERE character_id = ? ORDER BY created_at ASC")
    .all(req.params.id);
  res.json(messages);
});

// Gửi tin nhắn văn bản hoặc sticker
router.post("/text", async (req, res) => {
  const character = getCharacter(req.params.id);
  if (!character) return res.status(404).json({ error: "Không tìm thấy nhân vật" });

  const { content, type = "text" } = req.body;
  if (!content || !content.trim()) return res.status(400).json({ error: "Thiếu nội dung" });

  const userMessage = saveMessage(character.id, "user", type, content);
  touchCharacter(character.id);

  try {
    const { createdMessages, reaction } = await respondAndSave(character, null, content);
    if (reaction) {
      db.prepare("UPDATE messages SET reaction = ? WHERE id = ?").run(reaction, userMessage.id);
      userMessage.reaction = reaction;
    }
    res.status(201).json({ userMessage, aiMessages: createdMessages });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi khi gọi AI: " + err.message });
  }
});

// Gửi ảnh
router.post("/image", upload.single("image"), async (req, res) => {
  const character = getCharacter(req.params.id);
  if (!character) return res.status(404).json({ error: "Không tìm thấy nhân vật" });
  if (!req.file) return res.status(400).json({ error: "Thiếu file ảnh" });

  const relativePath = `/uploads/${req.file.filename}`;
  const userMessage = saveMessage(character.id, "user", "image", relativePath);
  touchCharacter(character.id);

  try {
    const { createdMessages, reaction } = await respondAndSave(
      character,
      req.file.path,
      req.body.caption || ""
    );
    if (reaction) {
      db.prepare("UPDATE messages SET reaction = ? WHERE id = ?").run(reaction, userMessage.id);
      userMessage.reaction = reaction;
    }
    res.status(201).json({ userMessage, aiMessages: createdMessages });
  } catch (err) {
    console.error(err);
    res.status(500).json({ error: "Lỗi khi gọi AI: " + err.message });
  }
});

// User tự thả reaction lên 1 tin nhắn bất kỳ
router.patch("/:messageId/reaction", (req, res) => {
  const { reaction } = req.body;
  db.prepare("UPDATE messages SET reaction = ? WHERE id = ?").run(reaction, req.params.messageId);
  const message = db.prepare("SELECT * FROM messages WHERE id = ?").get(req.params.messageId);
  res.json(message);
});

module.exports = router;
