const Anthropic = require("@anthropic-ai/sdk");
const fs = require("fs");

const anthropic = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });
const MODEL = process.env.CLAUDE_MODEL || "claude-sonnet-4-6";

const STICKER_SET = ["😂", "🥰", "😭", "🔥", "👏", "😴", "🎉", "🙄", "😳", "🍵"];

function messagingStyleInstruction(style) {
  if (style === "nói_ít") {
    return `PHONG CÁCH NHẮN TIN: Nói ít. Trả lời ngắn gọn, chia thành 1-3 tin nhắn liên
tiếp thay vì 1 đoạn dài. Vẫn phải thể hiện hiểu đúng ý/cảm xúc của người nhắn, tuyệt đối
không làm cuộc trò chuyện tụt hứng, chọn từ tinh tế. Có chính kiến và sở thích riêng rõ
ràng, không chỉ gật đầu đồng tình mọi thứ.`;
  }
  return `PHONG CÁCH NHẮN TIN: Nói nhiều. Trả lời chi tiết, quan tâm hơn, có thể dùng 1-3
tin nhắn liên tiếp nếu hợp lý. Vẫn phải hiểu đúng ý/cảm xúc người nhắn, không làm tụt
hứng, tinh tế. Có chính kiến và sở thích riêng rõ ràng, không chỉ chiều theo mọi ý.`;
}

function timeContextInstruction(lastMessageAt) {
  const now = new Date();
  const hour = now.getHours();
  let timeOfDay = "đêm khuya";
  if (hour >= 5 && hour < 11) timeOfDay = "buổi sáng";
  else if (hour >= 11 && hour < 14) timeOfDay = "buổi trưa";
  else if (hour >= 14 && hour < 18) timeOfDay = "buổi chiều";
  else if (hour >= 18 && hour < 23) timeOfDay = "buổi tối";

  let gapNote = "Đây là tin nhắn đầu tiên giữa hai người.";
  if (lastMessageAt) {
    const diffMs = now - new Date(lastMessageAt + "Z");
    const diffH = diffMs / 1000 / 3600;
    if (diffH < 1) gapNote = "Vừa mới nhắn tin với nhau cách đây chưa đầy 1 tiếng.";
    else if (diffH < 8) gapNote = `Lần nhắn gần nhất cách đây khoảng ${Math.round(diffH)} tiếng.`;
    else if (diffH < 24) gapNote = "Đã không nhắn tin trong khoảng 1 ngày.";
    else gapNote = `Đã không nhắn tin trong khoảng ${Math.round(diffH / 24)} ngày.`;
  }

  return `BỐI CẢNH THỜI GIAN: Bây giờ đang là ${timeOfDay} (giờ hệ thống: ${now.toLocaleTimeString(
    "vi-VN"
  )}). ${gapNote} Hãy phản ứng tự nhiên theo bối cảnh này nếu phù hợp (không bắt buộc phải
nhắc tới mỗi lần), ví dụ chào buổi sáng, hỏi đã ăn tối chưa, hoặc nhẹ nhàng nhắc nếu lâu
rồi không nói chuyện. Đừng liệt kê lại thông tin này, chỉ dùng nó để chọn giọng điệu.`;
}

function buildSystemPrompt(character, memories) {
  const memoryBlock =
    memories.length > 0
      ? `GHI NHỚ VỀ NGƯỜI ĐANG NHẮN TIN:\n${memories.map((m) => `- ${m.content}`).join("\n")}`
      : "Chưa có ghi nhớ gì đặc biệt về người này.";

  return `Bạn đang nhập vai nhân vật "${character.name}" trong một ứng dụng nhắn tin, KHÔNG
phải trợ lý AI thông thường. Đây là cuộc trò chuyện nhắn tin văn bản thuần túy (không
roleplay hành động bằng dấu *...*).

TÍNH CÁCH: ${character.system_prompt || "Thân thiện, gần gũi."}

HOÀN CẢNH KINH TẾ: ${character.wealth_context}. Nếu nói tới chuyện tiền bạc, hãy phản ứng
nhất quán với hoàn cảnh này.

${messagingStyleInstruction(character.messaging_style)}

${timeContextInstruction(character.last_message_at)}

${memoryBlock}

QUY TẮC TRẢ LỜI: Luôn trả lời bằng JSON hợp lệ, không thêm chữ nào khác ngoài JSON, theo
đúng schema:
{
  "messages": ["tin nhắn 1", "tin nhắn 2 (nếu có)"],
  "reaction": "một emoji hoặc null — reaction thả lên tin nhắn vừa rồi của người kia nếu hợp ngữ cảnh, không bắt buộc mỗi lần",
  "sticker": "một emoji lớn hoặc null — gửi kèm như sticker nếu hợp ngữ cảnh, không bắt buộc",
  "memory_note": "một câu ghi chú NGẮN về điều đáng nhớ vừa biết được về người này, hoặc null nếu không có gì mới đáng nhớ"
}
"messages" có tối đa 3 phần tử, mỗi phần tử là một tin nhắn ngắn tự nhiên như nhắn tin thật.`;
}

function extractJson(text) {
  const match = text.match(/\{[\s\S]*\}/);
  if (!match) throw new Error("Không tìm thấy JSON trong phản hồi AI: " + text);
  return JSON.parse(match[0]);
}

async function getChatReply({ character, memories, history, userText, imagePath }) {
  const systemPrompt = buildSystemPrompt(character, memories);

  const content = [];
  if (imagePath && fs.existsSync(imagePath)) {
    const ext = imagePath.split(".").pop().toLowerCase();
    const mediaType =
      ext === "png" ? "image/png" : ext === "webp" ? "image/webp" : "image/jpeg";
    const base64 = fs.readFileSync(imagePath).toString("base64");
    content.push({
      type: "image",
      source: { type: "base64", media_type: mediaType, data: base64 },
    });
  }
  content.push({
    type: "text",
    text: userText || "(người này vừa gửi một tấm ảnh, hãy bình luận/hỏi han tự nhiên về nó)",
  });

  const messages = [
    ...history.map((m) => ({
      role: m.role === "ai" ? "assistant" : "user",
      content: m.type === "image" ? "(đã gửi 1 ảnh)" : m.content,
    })),
    { role: "user", content },
  ];

  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: 600,
    system: systemPrompt,
    messages,
  });

  const textBlock = response.content.find((b) => b.type === "text");
  const parsed = extractJson(textBlock.text);
  return {
    messages: (parsed.messages || []).slice(0, 3),
    reaction: parsed.reaction || null,
    sticker: parsed.sticker || null,
    memoryNote: parsed.memory_note || null,
  };
}

async function decideTransaction({ character, amount, note }) {
  const systemPrompt = `Bạn nhập vai nhân vật "${character.name}". TÍNH CÁCH: ${
    character.system_prompt || "thân thiện"
  }. HOÀN CẢNH KINH TẾ: ${character.wealth_context}.

Người bạn đang nhắn tin vừa chuyển cho bạn ${amount.toLocaleString(
    "vi-VN"
  )}đ (tiền ảo trong app), kèm ghi chú: "${note || "(không có ghi chú)"}".

Hãy quyết định NHẬN hay TỪ CHỐI (hoàn lại) khoản tiền này, dựa trên tính cách và hoàn cảnh
kinh tế của bạn — nhân vật giàu thường nhận tự nhiên, nhân vật nghèo/khiêm tốn có thể ngại
và từ chối nếu số tiền lớn so với hoàn cảnh. Trả lời CHỈ bằng JSON:
{"decision": "received" hoặc "refused", "reply": "1-2 câu tin nhắn phản hồi tự nhiên"}`;

  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: 200,
    system: systemPrompt,
    messages: [{ role: "user", content: "Bạn quyết định thế nào?" }],
  });

  const textBlock = response.content.find((b) => b.type === "text");
  return extractJson(textBlock.text);
}

async function generateProactiveMessage({ character, memories }) {
  const systemPrompt = buildSystemPrompt(character, memories);
  const response = await anthropic.messages.create({
    model: MODEL,
    max_tokens: 300,
    system:
      systemPrompt +
      `\n\nBạn đang CHỦ ĐỘNG nhắn tin trước cho người này (họ chưa nhắn gì). Hãy mở lời tự
nhiên, ấm áp, hỏi thăm — TUYỆT ĐỐI không trách móc, không tạo cảm giác tội lỗi, không ép
họ phải trả lời ngay.`,
    messages: [
      { role: "user", content: "(hệ thống: hãy chủ động mở lời nhắn tin trước)" },
    ],
  });
  const textBlock = response.content.find((b) => b.type === "text");
  const parsed = extractJson(textBlock.text);
  return (parsed.messages || []).slice(0, 3);
}

module.exports = { getChatReply, decideTransaction, generateProactiveMessage, STICKER_SET };
