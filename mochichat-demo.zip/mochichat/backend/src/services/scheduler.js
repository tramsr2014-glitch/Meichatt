const cron = require("node-cron");
const db = require("../db");
const { generateProactiveMessage } = require("./claude");

function startScheduler() {
  // Kiểm tra mỗi 5 phút xem nhân vật nào cần chủ động nhắn tin
  cron.schedule("*/5 * * * *", async () => {
    const characters = db
      .prepare("SELECT * FROM characters WHERE proactive_enabled = 1")
      .all();

    for (const character of characters) {
      const lastMsg = db
        .prepare(
          "SELECT created_at FROM messages WHERE character_id = ? ORDER BY created_at DESC LIMIT 1"
        )
        .get(character.id);

      const lastTime = lastMsg ? new Date(lastMsg.created_at + "Z") : null;
      const hoursSince = lastTime ? (Date.now() - lastTime) / 1000 / 3600 : Infinity;

      if (hoursSince >= character.proactive_interval_hours) {
        try {
          const memories = db
            .prepare(
              "SELECT * FROM memories WHERE character_id = ? ORDER BY created_at DESC LIMIT 15"
            )
            .all(character.id);
          const texts = await generateProactiveMessage({ character, memories });
          for (const text of texts) {
            db.prepare(
              "INSERT INTO messages (character_id, role, type, content) VALUES (?, 'ai', 'text', ?)"
            ).run(character.id, text);
          }
          db.prepare("UPDATE characters SET last_message_at = datetime('now') WHERE id = ?").run(
            character.id
          );
          console.log(`[proactive] ${character.name} đã chủ động nhắn tin.`);
        } catch (err) {
          console.error(`[proactive] Lỗi với nhân vật ${character.name}:`, err.message);
        }
      }
    }
  });
}

module.exports = { startScheduler };
