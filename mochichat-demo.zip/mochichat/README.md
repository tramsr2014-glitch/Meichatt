# Mochichat Demo

Web app chat với các nhân vật AI tự tạo — tham khảo tính năng của Mochichat. Demo này
chạy hoàn toàn local trên máy bạn, có backend + database SQLite thật để dữ liệu không mất
khi tắt trình duyệt.

## Tính năng
- Tạo/sửa/xoá nhân vật AI (tên, avatar, tính cách, hoàn cảnh kinh tế, phong cách nhắn tin).
- Chat riêng theo từng nhân vật, lưu lịch sử vào SQLite.
- Trí nhớ dài hạn: AI tự rút ra và ghi nhớ thông tin về bạn qua các lần chat.
- Chuyển tiền ảo (VNĐ) cho nhân vật kiểu WeChat Pay — có xác nhận trước/sau, AI tự quyết
  định nhận hay từ chối dựa trên hoàn cảnh kinh tế đã đặt cho nhân vật.
- Nhân vật có thể chủ động nhắn tin trước theo tần suất bạn cài đặt (chạy nền bằng cron).
- Nhận thức thời gian: AI biết giờ hiện tại và đã bao lâu chưa nói chuyện để phản ứng tự
  nhiên.
- Emoji reaction 2 chiều (bạn thả tim/haha lên tin nhắn AI, AI cũng có thể thả lên tin
  nhắn bạn).
- Sticker biểu cảm (emoji phóng to).
- Gửi ảnh trong chat — AI "nhìn" ảnh (dùng khả năng vision của Claude) và bình luận tự
  nhiên, ví dụ ảnh đồ ăn thì hỏi ngon không.
- Giao diện tối giản kiểu TikTok DM, có chế độ sáng/tối.

## Yêu cầu
- Node.js 18+ (khuyến nghị 20+)
- 1 API key của Anthropic (lấy tại https://console.anthropic.com)

## Cài đặt & chạy

### 1. Backend
```bash
cd backend
npm install
cp .env.example .env
# Mở file .env, dán API key thật của bạn vào ANTHROPIC_API_KEY
npm run dev
```
Backend chạy tại `http://localhost:4000`, tự tạo file database `mochichat.db` khi chạy
lần đầu.

### 2. Frontend
Mở terminal khác:
```bash
cd frontend
npm install
npm run dev
```
Mở trình duyệt tại địa chỉ mà Vite in ra (thường là `http://localhost:5173`).

## Cấu trúc dự án
```
mochichat/
  backend/
    src/
      db.js               # schema SQLite
      server.js            # entry point Express
      routes/               # characters, messages, wallet
      services/claude.js    # gọi Anthropic API
      services/scheduler.js # cron cho tính năng chủ động nhắn tin
    uploads/                # ảnh user gửi lên được lưu ở đây
  frontend/
    src/
      App.jsx
      components/           # CharacterList, ChatWindow, MessageBubble, TransferModal...
```

## Ghi chú khi mở rộng
- Muốn đổi model Claude: sửa `CLAUDE_MODEL` trong `backend/.env`.
- Muốn thêm tài khoản nhiều người dùng thật: cần thêm bảng `users`, middleware xác thực,
  và tách ví/nhân vật theo `user_id` — hiện tại DB đang giả định chỉ 1 người dùng.
- Muốn deploy public: cần thêm HTTPS, rate limiting, và không để lộ `.env`/API key.
