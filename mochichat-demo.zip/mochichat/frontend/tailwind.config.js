/** @type {import('tailwindcss').Config} */
export default {
  darkMode: "class",
  content: ["./index.html", "./src/**/*.{js,jsx}"],
  theme: {
    extend: {
      colors: {
        brand: {
          50: "#fff1f5",
          100: "#ffe1ea",
          400: "#ff5c8a",
          500: "#fe2c55", // sắc hồng-đỏ kiểu TikTok
          600: "#e0234a",
        },
      },
    },
  },
  plugins: [],
};
