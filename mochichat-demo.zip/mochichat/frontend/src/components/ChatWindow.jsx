import { useEffect, useRef, useState } from "react";
import MessageBubble from "./MessageBubble";
import StickerPicker from "./StickerPicker";

export default function ChatWindow({
  character,
  messages,
  sending,
  stickers,
  onSendText,
  onSendImage,
  onReact,
  onOpenTransfer,
  onEditCharacter,
}) {
  const [text, setText] = useState("");
  const [showStickers, setShowStickers] = useState(false);
  const bottomRef = useRef(null);
  const fileInputRef = useRef(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: "smooth" });
  }, [messages, sending]);

  if (!character) {
    return (
      <div className="flex-1 flex items-center justify-center text-neutral-400">
        Chọn một nhân vật để bắt đầu nhắn tin
      </div>
    );
  }

  const submitText = () => {
    if (!text.trim()) return;
    onSendText(text.trim());
    setText("");
  };

  return (
    <div className="flex-1 flex flex-col h-full bg-neutral-50 dark:bg-neutral-950 relative">
      {/* Header */}
      <div className="flex items-center gap-3 px-4 py-3 border-b border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
        <div className="w-10 h-10 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-xl">
          {character.avatar}
        </div>
        <div className="flex-1 min-w-0">
          <div className="font-semibold text-neutral-900 dark:text-white truncate">
            {character.name}
          </div>
        </div>
        <button
          onClick={onOpenTransfer}
          className="px-3 py-1.5 rounded-full bg-brand-50 dark:bg-neutral-800 text-brand-600 dark:text-brand-400 text-sm font-medium"
        >
          💸 Chuyển tiền
        </button>
        <button
          onClick={onEditCharacter}
          className="w-8 h-8 rounded-full hover:bg-neutral-100 dark:hover:bg-neutral-800 flex items-center justify-center text-neutral-500"
          title="Sửa nhân vật"
        >
          ⚙️
        </button>
      </div>

      {/* Messages */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-4 py-4">
        {messages.map((m) => (
          <MessageBubble
            key={m.id}
            message={m}
            characterAvatar={character.avatar}
            onReact={(id, reaction) => onReact(id, reaction)}
          />
        ))}
        {sending && (
          <div className="flex items-center gap-1 ml-9 mb-2">
            <span className="typing-dot w-1.5 h-1.5 rounded-full bg-neutral-400" style={{ animationDelay: "0s" }} />
            <span className="typing-dot w-1.5 h-1.5 rounded-full bg-neutral-400" style={{ animationDelay: "0.2s" }} />
            <span className="typing-dot w-1.5 h-1.5 rounded-full bg-neutral-400" style={{ animationDelay: "0.4s" }} />
          </div>
        )}
        <div ref={bottomRef} />
      </div>

      {/* Sticker picker */}
      {showStickers && (
        <StickerPicker
          stickers={stickers}
          onClose={() => setShowStickers(false)}
          onPick={(s) => onSendText(s, "sticker")}
        />
      )}

      {/* Input bar */}
      <div className="flex items-center gap-2 px-3 py-3 border-t border-neutral-200 dark:border-neutral-800 bg-white dark:bg-neutral-900">
        <button
          onClick={() => setShowStickers((s) => !s)}
          className="w-9 h-9 flex items-center justify-center text-xl shrink-0"
          title="Sticker"
        >
          😊
        </button>
        <button
          onClick={() => fileInputRef.current?.click()}
          className="w-9 h-9 flex items-center justify-center text-xl shrink-0"
          title="Gửi ảnh"
        >
          📷
        </button>
        <input
          type="file"
          accept="image/*"
          ref={fileInputRef}
          className="hidden"
          onChange={(e) => {
            const file = e.target.files?.[0];
            if (file) onSendImage(file);
            e.target.value = "";
          }}
        />
        <input
          value={text}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => e.key === "Enter" && submitText()}
          placeholder="Nhắn tin..."
          className="flex-1 px-4 py-2 rounded-full bg-neutral-100 dark:bg-neutral-800 outline-none text-neutral-900 dark:text-white"
        />
        <button
          onClick={submitText}
          disabled={!text.trim()}
          className="w-9 h-9 rounded-full bg-brand-500 text-white flex items-center justify-center disabled:opacity-40 shrink-0"
        >
          ➤
        </button>
      </div>
    </div>
  );
}
