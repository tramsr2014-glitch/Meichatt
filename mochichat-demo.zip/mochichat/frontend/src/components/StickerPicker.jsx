export default function StickerPicker({ stickers, onPick, onClose }) {
  return (
    <div className="absolute bottom-16 left-0 right-0 mx-4 bg-white dark:bg-neutral-900 shadow-xl rounded-2xl p-3 grid grid-cols-5 gap-2 z-20">
      {stickers.map((s) => (
        <button
          key={s}
          onClick={() => {
            onPick(s);
            onClose();
          }}
          className="text-3xl hover:scale-125 transition py-1"
        >
          {s}
        </button>
      ))}
    </div>
  );
}
