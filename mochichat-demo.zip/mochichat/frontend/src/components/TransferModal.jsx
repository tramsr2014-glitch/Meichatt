import { useState } from "react";

export default function TransferModal({ wallet, onConfirm, onCancel }) {
  const [amount, setAmount] = useState("");
  const [note, setNote] = useState("");
  const [step, setStep] = useState("input"); // 'input' | 'confirm'

  const numAmount = Number(amount) || 0;
  const after = (wallet?.balance || 0) - numAmount;
  const valid = numAmount > 0 && numAmount <= (wallet?.balance || 0);

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-sm p-5">
        {step === "input" ? (
          <>
            <h2 className="text-lg font-bold mb-4 text-neutral-900 dark:text-white">
              Chuyển tiền
            </h2>
            <div className="text-sm text-neutral-500 mb-3">
              Số dư ví: <b>{(wallet?.balance || 0).toLocaleString("vi-VN")}đ</b>
            </div>
            <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
              Số tiền (VNĐ)
            </label>
            <input
              type="number"
              value={amount}
              onChange={(e) => setAmount(e.target.value)}
              placeholder="VD: 50000"
              className="w-full mt-1 mb-3 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
            />
            <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
              Ghi chú (tuỳ chọn)
            </label>
            <input
              value={note}
              onChange={(e) => setNote(e.target.value)}
              placeholder="VD: mời cậu ly cà phê"
              className="w-full mt-1 mb-4 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
            />
            {!valid && numAmount > 0 && (
              <p className="text-xs text-red-500 mb-2">Số dư trong ví không đủ.</p>
            )}
            <div className="flex gap-2">
              <button
                onClick={onCancel}
                className="flex-1 py-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200"
              >
                Huỷ
              </button>
              <button
                disabled={!valid}
                onClick={() => setStep("confirm")}
                className="flex-1 py-2 rounded-lg bg-brand-500 text-white disabled:opacity-40"
              >
                Tiếp tục
              </button>
            </div>
          </>
        ) : (
          <>
            <h2 className="text-lg font-bold mb-4 text-neutral-900 dark:text-white">
              Xác nhận chuyển tiền
            </h2>
            <div className="space-y-2 text-sm text-neutral-700 dark:text-neutral-200 mb-4">
              <Row label="Số dư hiện tại" value={`${wallet.balance.toLocaleString("vi-VN")}đ`} />
              <Row label="Số tiền chuyển" value={`${numAmount.toLocaleString("vi-VN")}đ`} bold />
              <Row label="Ghi chú" value={note || "(không có)"} />
              <Row label="Số dư sau khi chuyển" value={`${after.toLocaleString("vi-VN")}đ`} />
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setStep("input")}
                className="flex-1 py-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200"
              >
                Quay lại
              </button>
              <button
                onClick={() => onConfirm(numAmount, note)}
                className="flex-1 py-2 rounded-lg bg-brand-500 text-white"
              >
                Xác nhận chuyển
              </button>
            </div>
          </>
        )}
      </div>
    </div>
  );
}

function Row({ label, value, bold }) {
  return (
    <div className="flex justify-between">
      <span className="text-neutral-400">{label}</span>
      <span className={bold ? "font-bold text-brand-500" : ""}>{value}</span>
    </div>
  );
}
