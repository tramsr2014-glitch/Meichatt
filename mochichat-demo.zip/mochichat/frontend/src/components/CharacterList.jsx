export default function CharacterList({
  characters,
  selectedId,
  onSelect,
  onCreate,
  wallet,
  onOpenWalletHistory,
}) {
  return (
    <div className="w-full sm:w-80 shrink-0 border-r border-neutral-200 dark:border-neutral-800 flex flex-col h-full bg-white dark:bg-neutral-950">
      <div className="p-4 flex items-center justify-between">
        <h1 className="text-lg font-bold text-neutral-900 dark:text-white">Mochichat Demo</h1>
        <button
          onClick={onCreate}
          className="w-8 h-8 rounded-full bg-brand-500 text-white flex items-center justify-center text-xl leading-none hover:bg-brand-600 transition"
          title="Tạo nhân vật mới"
        >
          +
        </button>
      </div>

      <button
        onClick={onOpenWalletHistory}
        className="mx-4 mb-3 px-3 py-2 rounded-xl bg-brand-50 dark:bg-neutral-900 text-left hover:opacity-80 transition"
      >
        <div className="text-xs text-neutral-500 dark:text-neutral-400">Ví của bạn</div>
        <div className="text-base font-semibold text-brand-600 dark:text-brand-400">
          {wallet ? wallet.balance.toLocaleString("vi-VN") : "..."}đ
        </div>
      </button>

      <div className="flex-1 overflow-y-auto no-scrollbar">
        {characters.length === 0 && (
          <p className="text-center text-sm text-neutral-400 mt-10 px-6">
            Chưa có nhân vật nào. Bấm nút + để tạo nhân vật đầu tiên của bạn.
          </p>
        )}
        {characters.map((c) => (
          <button
            key={c.id}
            onClick={() => onSelect(c)}
            className={`w-full flex items-center gap-3 px-4 py-3 text-left transition ${
              selectedId === c.id
                ? "bg-brand-50 dark:bg-neutral-900"
                : "hover:bg-neutral-50 dark:hover:bg-neutral-900"
            }`}
          >
            <div className="w-11 h-11 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-2xl shrink-0">
              {c.avatar}
            </div>
            <div className="min-w-0">
              <div className="font-medium text-neutral-900 dark:text-white truncate">
                {c.name}
              </div>
              <div className="text-xs text-neutral-400 truncate">
                {c.messaging_style === "nói_ít" ? "Nói ít" : "Nói nhiều"} ·{" "}
                {c.proactive_enabled ? `chủ động mỗi ${c.proactive_interval_hours}h` : "im lặng"}
              </div>
            </div>
          </button>
        ))}
      </div>
    </div>
  );
}
