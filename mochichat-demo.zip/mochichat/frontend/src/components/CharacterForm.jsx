import { useState } from "react";

const AVATAR_CHOICES = ["🙂", "😺", "🐻", "🌸", "🐰", "🦊", "🧑‍💻", "👩‍🎨", "🧕", "🧔"];

export default function CharacterForm({ initial, onSave, onCancel, onDelete }) {
  const [form, setForm] = useState(
    initial || {
      name: "",
      avatar: "🙂",
      system_prompt: "",
      wealth_context: "bình thường, đủ sống",
      messaging_style: "nói_nhiều",
      proactive_enabled: false,
      proactive_interval_hours: 4,
    }
  );

  const set = (key, value) => setForm((f) => ({ ...f, [key]: value }));

  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-md p-5 max-h-[90vh] overflow-y-auto">
        <h2 className="text-lg font-bold mb-4 text-neutral-900 dark:text-white">
          {initial ? "Sửa nhân vật" : "Tạo nhân vật mới"}
        </h2>

        <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">Tên</label>
        <input
          value={form.name}
          onChange={(e) => set("name", e.target.value)}
          placeholder="VD: Minh Anh"
          className="w-full mt-1 mb-3 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
        />

        <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
          Avatar
        </label>
        <div className="flex flex-wrap gap-2 mt-1 mb-3">
          {AVATAR_CHOICES.map((a) => (
            <button
              key={a}
              onClick={() => set("avatar", a)}
              className={`w-10 h-10 rounded-full text-xl flex items-center justify-center border-2 ${
                form.avatar === a
                  ? "border-brand-500"
                  : "border-transparent bg-neutral-100 dark:bg-neutral-800"
              }`}
            >
              {a}
            </button>
          ))}
        </div>

        <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
          Tính cách (system prompt)
        </label>
        <textarea
          value={form.system_prompt}
          onChange={(e) => set("system_prompt", e.target.value)}
          placeholder="VD: Vui vẻ, hài hước, thích nhạc indie, hay trêu chọc bạn bè..."
          rows={3}
          className="w-full mt-1 mb-3 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
        />

        <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
          Hoàn cảnh kinh tế
        </label>
        <input
          value={form.wealth_context}
          onChange={(e) => set("wealth_context", e.target.value)}
          placeholder="VD: sinh viên nghèo / doanh nhân giàu có / bình thường"
          className="w-full mt-1 mb-3 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
        />

        <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
          Phong cách nhắn tin
        </label>
        <div className="flex gap-2 mt-1 mb-3">
          {[
            { key: "nói_ít", label: "Nói ít" },
            { key: "nói_nhiều", label: "Nói nhiều" },
          ].map((opt) => (
            <button
              key={opt.key}
              onClick={() => set("messaging_style", opt.key)}
              className={`px-3 py-1.5 rounded-full text-sm ${
                form.messaging_style === opt.key
                  ? "bg-brand-500 text-white"
                  : "bg-neutral-100 dark:bg-neutral-800 text-neutral-600 dark:text-neutral-300"
              }`}
            >
              {opt.label}
            </button>
          ))}
        </div>

        <div className="flex items-center justify-between mb-2">
          <label className="text-sm font-medium text-neutral-600 dark:text-neutral-300">
            Chủ động nhắn tin trước
          </label>
          <input
            type="checkbox"
            checked={!!form.proactive_enabled}
            onChange={(e) => set("proactive_enabled", e.target.checked)}
          />
        </div>
        {form.proactive_enabled && (
          <div className="mb-3">
            <label className="text-xs text-neutral-500">Tần suất (giờ)</label>
            <input
              type="number"
              min={1}
              step={1}
              value={form.proactive_interval_hours}
              onChange={(e) => set("proactive_interval_hours", Number(e.target.value))}
              className="w-full mt-1 px-3 py-2 rounded-lg border border-neutral-200 dark:border-neutral-700 bg-transparent dark:text-white"
            />
          </div>
        )}

        <div className="flex gap-2 mt-4">
          <button
            onClick={onCancel}
            className="flex-1 py-2 rounded-lg bg-neutral-100 dark:bg-neutral-800 text-neutral-700 dark:text-neutral-200"
          >
            Huỷ
          </button>
          <button
            onClick={() => onSave(form)}
            disabled={!form.name.trim()}
            className="flex-1 py-2 rounded-lg bg-brand-500 text-white disabled:opacity-40"
          >
            Lưu
          </button>
        </div>
        {initial && (
          <button
            onClick={onDelete}
            className="w-full mt-2 py-2 rounded-lg text-red-500 text-sm hover:bg-red-50 dark:hover:bg-red-950/30"
          >
            Xoá nhân vật
          </button>
        )}
      </div>
    </div>
  );
}
