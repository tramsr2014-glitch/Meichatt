const STATUS_LABEL = {
  pending: "Đang chờ",
  received: "Đã nhận",
  refunded: "Đã hoàn lại",
};

export default function WalletHistory({ transactions, wallet, onClose }) {
  return (
    <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50 p-4">
      <div className="bg-white dark:bg-neutral-900 rounded-2xl w-full max-w-md p-5 max-h-[85vh] flex flex-col">
        <div className="flex items-center justify-between mb-3">
          <h2 className="text-lg font-bold text-neutral-900 dark:text-white">Lịch sử giao dịch</h2>
          <button onClick={onClose} className="text-neutral-400 text-xl leading-none">
            ×
          </button>
        </div>
        <div className="text-sm text-neutral-500 mb-4">
          Số dư ví: <b className="text-brand-500">{(wallet?.balance || 0).toLocaleString("vi-VN")}đ</b>{" "}
          / hạn mức {(wallet?.spending_limit || 0).toLocaleString("vi-VN")}đ
        </div>
        <div className="flex-1 overflow-y-auto no-scrollbar space-y-2">
          {transactions.length === 0 && (
            <p className="text-sm text-neutral-400 text-center mt-8">Chưa có giao dịch nào.</p>
          )}
          {transactions.map((t) => (
            <div
              key={t.id}
              className="flex items-center gap-3 p-3 rounded-xl bg-neutral-50 dark:bg-neutral-800"
            >
              <div className="w-9 h-9 rounded-full bg-white dark:bg-neutral-700 flex items-center justify-center text-lg">
                {t.character_avatar}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-sm font-medium text-neutral-800 dark:text-white truncate">
                  {t.character_name}
                </div>
                <div className="text-xs text-neutral-400 truncate">{t.note || "(không có ghi chú)"}</div>
              </div>
              <div className="text-right">
                <div className="text-sm font-semibold text-neutral-800 dark:text-white">
                  {t.amount.toLocaleString("vi-VN")}đ
                </div>
                <div
                  className={`text-xs ${
                    t.status === "received"
                      ? "text-green-500"
                      : t.status === "refunded"
                      ? "text-amber-500"
                      : "text-neutral-400"
                  }`}
                >
                  {STATUS_LABEL[t.status]}
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}
