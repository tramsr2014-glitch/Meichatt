import { useState } from "react";

const REACTIONS = ["❤️", "😂", "😮", "😢", "👍"];

export default function MessageBubble({ message, characterAvatar, onReact }) {
  const [showPicker, setShowPicker] = useState(false);
  const isUser = message.role === "user";

  const time = new Date((message.created_at || "") + "Z").toLocaleTimeString("vi-VN", {
    hour: "2-digit",
    minute: "2-digit",
  });

  let body;
  if (message.type === "sticker") {
    body = <div className="text-5xl leading-none animate-pop-in">{message.content}</div>;
  } else if (message.type === "image") {
    body = (
      <img
        src={message.content}
        alt="ảnh gửi trong chat"
        className="max-w-[220px] rounded-2xl object-cover"
      />
    );
  } else if (message.type === "transfer") {
    let data = {};
    try {
      data = JSON.parse(message.content);
    } catch {
      /* ignore */
    }
    body = (
      <div className="px-4 py-3 rounded-2xl bg-gradient-to-br from-brand-500 to-amber-400 text-white min-w-[180px]">
        <div className="text-xs opacity-90">💸 Đã chuyển</div>
        <div className="text-xl font-bold">{Number(data.amount || 0).toLocaleString("vi-VN")}đ</div>
        {data.note && <div className="text-xs mt-1 opacity-90">"{data.note}"</div>}
      </div>
    );
  } else {
    body = (
      <div
        className={`px-4 py-2 rounded-2xl max-w-[75%] whitespace-pre-wrap break-words ${
          isUser
            ? "bg-brand-500 text-white rounded-br-sm"
            : "bg-neutral-100 dark:bg-neutral-800 text-neutral-900 dark:text-white rounded-bl-sm"
        }`}
      >
        {message.content}
      </div>
    );
  }

  return (
    <div className={`flex items-end gap-2 mb-1 ${isUser ? "justify-end" : "justify-start"}`}>
      {!isUser && (
        <div className="w-7 h-7 rounded-full bg-neutral-100 dark:bg-neutral-800 flex items-center justify-center text-sm shrink-0">
          {characterAvatar}
        </div>
      )}
      <div className="relative">
        <div onClick={() => setShowPicker((s) => !s)} className="cursor-pointer select-none">
          {body}
        </div>

        {message.reaction && (
          <div className="absolute -bottom-2 -right-1 bg-white dark:bg-neutral-900 rounded-full text-xs px-1 shadow">
            {message.reaction}
          </div>
        )}

        {showPicker && (
          <div className="absolute z-10 -top-10 left-0 bg-white dark:bg-neutral-800 shadow-lg rounded-full px-2 py-1 flex gap-1">
            {REACTIONS.map((r) => (
              <button
                key={r}
                onClick={() => {
                  onReact(message.id, r);
                  setShowPicker(false);
                }}
                className="text-lg hover:scale-125 transition"
              >
                {r}
              </button>
            ))}
          </div>
        )}

        <div
          className={`text-[10px] text-neutral-400 mt-0.5 ${isUser ? "text-right" : "text-left"}`}
        >
          {time}
        </div>
      </div>
    </div>
  );
}
