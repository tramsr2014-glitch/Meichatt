import { useEffect, useState } from "react";
import { api } from "./api";
import CharacterList from "./components/CharacterList";
import CharacterForm from "./components/CharacterForm";
import ChatWindow from "./components/ChatWindow";
import TransferModal from "./components/TransferModal";
import WalletHistory from "./components/WalletHistory";

export default function App() {
  const [dark, setDark] = useState(false);
  const [characters, setCharacters] = useState([]);
  const [selected, setSelected] = useState(null);
  const [messages, setMessages] = useState([]);
  const [sending, setSending] = useState(false);
  const [stickers, setStickers] = useState([]);
  const [wallet, setWallet] = useState(null);
  const [transactions, setTransactions] = useState([]);

  const [showForm, setShowForm] = useState(false);
  const [editingCharacter, setEditingCharacter] = useState(null);
  const [showTransfer, setShowTransfer] = useState(false);
  const [showWalletHistory, setShowWalletHistory] = useState(false);
  const [error, setError] = useState("");

  useEffect(() => {
    document.documentElement.classList.toggle("dark", dark);
  }, [dark]);

  const refreshCharacters = () => api.getCharacters().then(setCharacters);
  const refreshWallet = () => api.getWallet().then(setWallet);

  useEffect(() => {
    refreshCharacters();
    refreshWallet();
    api.getStickers().then(setStickers);
  }, []);

  useEffect(() => {
    if (selected) {
      api.getMessages(selected.id).then(setMessages);
      // poll nhẹ để nhận tin nhắn chủ động từ scheduler
      const interval = setInterval(() => {
        api.getMessages(selected.id).then(setMessages);
      }, 15000);
      return () => clearInterval(interval);
    }
  }, [selected]);

  const handleCreateOrUpdate = async (form) => {
    try {
      if (editingCharacter) {
        await api.updateCharacter(editingCharacter.id, form);
      } else {
        const created = await api.createCharacter(form);
        setSelected(created);
      }
      setShowForm(false);
      setEditingCharacter(null);
      refreshCharacters();
    } catch (e) {
      setError(e.message);
    }
  };

  const handleDelete = async () => {
    if (!editingCharacter) return;
    await api.deleteCharacter(editingCharacter.id);
    if (selected?.id === editingCharacter.id) setSelected(null);
    setShowForm(false);
    setEditingCharacter(null);
    refreshCharacters();
  };

  const handleSendText = async (content, type = "text") => {
    if (!selected) return;
    setSending(true);
    setError("");
    // optimistic update cho tin nhắn user
    const tempId = `temp-${Date.now()}`;
    setMessages((m) => [
      ...m,
      { id: tempId, role: "user", type, content, created_at: new Date().toISOString() },
    ]);
    try {
      const res = await api.sendText(selected.id, content, type);
      setMessages((m) => {
        const withoutTemp = m.filter((msg) => msg.id !== tempId);
        return [...withoutTemp, res.userMessage, ...res.aiMessages];
      });
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  };

  const handleSendImage = async (file) => {
    if (!selected) return;
    setSending(true);
    setError("");
    try {
      const res = await api.sendImage(selected.id, file);
      setMessages((m) => [...m, res.userMessage, ...res.aiMessages]);
    } catch (e) {
      setError(e.message);
    } finally {
      setSending(false);
    }
  };

  const handleReact = async (messageId, reaction) => {
    if (!selected) return;
    await api.setReaction(selected.id, messageId, reaction);
    setMessages((m) => m.map((msg) => (msg.id === messageId ? { ...msg, reaction } : msg)));
  };

  const handleTransfer = async (amount, note) => {
    if (!selected) return;
    try {
      const res = await api.transfer(selected.id, amount, note);
      setWallet(res.wallet);
      setShowTransfer(false);
      api.getMessages(selected.id).then(setMessages);
    } catch (e) {
      setError(e.message);
    }
  };

  const openWalletHistory = async () => {
    const [w, tx] = await Promise.all([api.getWallet(), api.getTransactions()]);
    setWallet(w);
    setTransactions(tx);
    setShowWalletHistory(true);
  };

  return (
    <div className="h-screen w-screen flex overflow-hidden">
      <CharacterList
        characters={characters}
        selectedId={selected?.id}
        onSelect={setSelected}
        onCreate={() => {
          setEditingCharacter(null);
          setShowForm(true);
        }}
        wallet={wallet}
        onOpenWalletHistory={openWalletHistory}
      />

      <ChatWindow
        character={selected}
        messages={messages}
        sending={sending}
        stickers={stickers}
        onSendText={handleSendText}
        onSendImage={handleSendImage}
        onReact={handleReact}
        onOpenTransfer={() => setShowTransfer(true)}
        onEditCharacter={() => {
          setEditingCharacter(selected);
          setShowForm(true);
        }}
      />

      <button
        onClick={() => setDark((d) => !d)}
        className="fixed bottom-4 right-4 w-10 h-10 rounded-full bg-neutral-800 dark:bg-white text-white dark:text-neutral-900 flex items-center justify-center shadow-lg z-30"
        title="Đổi giao diện sáng/tối"
      >
        {dark ? "☀️" : "🌙"}
      </button>

      {error && (
        <div className="fixed top-4 left-1/2 -translate-x-1/2 bg-red-500 text-white text-sm px-4 py-2 rounded-full shadow-lg z-50">
          {error}
        </div>
      )}

      {showForm && (
        <CharacterForm
          initial={editingCharacter}
          onSave={handleCreateOrUpdate}
          onCancel={() => {
            setShowForm(false);
            setEditingCharacter(null);
          }}
          onDelete={handleDelete}
        />
      )}

      {showTransfer && (
        <TransferModal
          wallet={wallet}
          onConfirm={handleTransfer}
          onCancel={() => setShowTransfer(false)}
        />
      )}

      {showWalletHistory && (
        <WalletHistory
          wallet={wallet}
          transactions={transactions}
          onClose={() => setShowWalletHistory(false)}
        />
      )}
    </div>
  );
}
