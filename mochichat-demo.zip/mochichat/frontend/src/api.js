const BASE = "/api";

async function handle(res) {
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `Lỗi HTTP ${res.status}`);
  }
  return res.status === 204 ? null : res.json();
}

export const api = {
  getCharacters: () => fetch(`${BASE}/characters`).then(handle),
  getCharacter: (id) => fetch(`${BASE}/characters/${id}`).then(handle),
  createCharacter: (data) =>
    fetch(`${BASE}/characters`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(handle),
  updateCharacter: (id, data) =>
    fetch(`${BASE}/characters/${id}`, {
      method: "PUT",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(data),
    }).then(handle),
  deleteCharacter: (id) => fetch(`${BASE}/characters/${id}`, { method: "DELETE" }).then(handle),

  getMessages: (characterId) =>
    fetch(`${BASE}/characters/${characterId}/messages`).then(handle),
  sendText: (characterId, content, type = "text") =>
    fetch(`${BASE}/characters/${characterId}/messages/text`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ content, type }),
    }).then(handle),
  sendImage: (characterId, file, caption) => {
    const form = new FormData();
    form.append("image", file);
    if (caption) form.append("caption", caption);
    return fetch(`${BASE}/characters/${characterId}/messages/image`, {
      method: "POST",
      body: form,
    }).then(handle);
  },
  setReaction: (characterId, messageId, reaction) =>
    fetch(`${BASE}/characters/${characterId}/messages/${messageId}/reaction`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ reaction }),
    }).then(handle),

  getStickers: () => fetch(`${BASE}/stickers`).then(handle),

  getWallet: () => fetch(`${BASE}/wallet`).then(handle),
  getTransactions: () => fetch(`${BASE}/wallet/transactions`).then(handle),
  transfer: (characterId, amount, note) =>
    fetch(`${BASE}/wallet/characters/${characterId}/transfer`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ amount, note }),
    }).then(handle),
};
